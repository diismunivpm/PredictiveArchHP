# -*- coding: utf-8 -*-
"""
-------------------------------------------------------------------------------
Update version (25 october 2023)
@author: AMugnini
-------------------------------------------------------------------------------
"""
import xlsxwriter
import pandas 
import numpy as np
from   gekko import GEKKO

def PolynomialCoefficientHP_HC():
    """
    --------------------------------------------------------------------------------------------
    Plynomial coefficient for the HP model (equation for HC)
    --------------------------------------------------------------------------------------------
    """
    P_norm = [-7.2486987257, 4.5036792304, -0.070427512888]
    P_max  = [9922.9152571, -74.035128715, 0.49597259514]
    P_min  = [9900.7470713, -78.150909991, 0.55532453836]
    return(P_norm,P_max,P_min)

def PolynomialCoefficientHP_Pl():    
    """
    --------------------------------------------------------------------------------------------
    Plynomial coefficient for the HP model (equation for Pl)
    --------------------------------------------------------------------------------------------
    """
    P_ebt = [0.11886085397, 0.6388859793, -0.056597319403, 0.0013000901113]
    P_lwc = [0.11956408425, 0.16098924884, 0.0019264841354, -2.1001154385e-05]
    P_cr  = [-0.11279610066, 278.08858579, -244.74815272, 229.87631828, -64.710510214]
    return(P_ebt,P_lwc,P_cr)

def DegradationFactor():   
    factor = [2.406592465,-23.27915444,168.5090027,-702.77231653,1871.2897708,-3327.1561237,4004.8281137,-3226.3396905,1667.0047907,-499.47941196,65.988437212]
    return factor

def PolynomialCoefficientHP_Rad():   
    P_sup = [-14954.845545,553.01603155]
    return P_sup


def BuildingParameters():  
    """
    --------------------------------------------------------------------------------------------
    Numerical values of the LPM
    --------------------------------------------------------------------------------------------
    """   
    Cair_z1	    = 551.26095469
    Ce_z1	    = 5523.4073299
    Ctm	        = 1587591.2
    Keo_z1	    = 72.136150234
    Kei_z1	    = 200.54255398
    Ktm_ff	    = 374.11000376
    Kwindinf_z1 = 61.708959005
    p_z1	    = 0.053064464435
    Cair_z2	    = 754.27903602
    Ce_z2	    = 8059.9504196
    Keo_z2	    = 116.06656029
    Kei_z2	    = 313.04894105
    Ktm_sf	    = 265.87938347
    Kwindinf_z2	= 43.60081553
    p_z2	    = 0.06954424653
    
    C    = [Cair_z1,Ce_z1,Ctm,Cair_z2,Ce_z2]
    K_z1 = [Keo_z1,Kei_z1,Ktm_ff,Kwindinf_z1]
    K_z2 = [Keo_z2,Kei_z2,Ktm_sf,Kwindinf_z2]
    
    return(C,K_z1,K_z2,p_z1,p_z2)


def InputPredicted(timestep_hr,starting_time_hr,PH):
    """
    --------------------------------------------------------------------------------------------
    Function to select input for LPM in PH
    --------------------------------------------------------------------------------------------
    """    
    data_part1_name = "ClimateData_TypWeek.xlsx"    
    data_part1      = pandas.read_excel(data_part1_name) 
    t_sta           = int(starting_time_hr/timestep_hr)
    t_end           = int((starting_time_hr+PH)/timestep_hr)    
    Tout_K          = data_part1.iloc[t_sta:t_end, 1].values.tolist()
    GS              = data_part1.iloc[t_sta:t_end, 2].values.tolist()       
    Toutdoor        = [T-273.15 for T in Tout_K]   
    Tground         = [13 for g in range(0,len(Tout_K))]
    Gs              = [31.4*g for g in GS]
    WEATHER         = [Toutdoor,Tground,Gs]
    return(WEATHER)


def EMPC1(SETTINGS,STARTING_states,STARTING_heating_system,DISTURBANCES):
    """
    --------------------------------------------------------------------------------------------
    Function for optimization in EMPS
    --------------------------------------------------------------------------------------------
    """
    [timestep_hr,PH,Tair_min,Tair_max]                                                                 = SETTINGS
    [Tz_1_in,Tz_2_in,Ttm_in,Twall_N,Twall_O,Twall_Z,Twall_W]                                           = STARTING_states
    [Qh1_in,Qh2_in,Tin_COND_in,Tout_COND_in, EBT_in, FR_COND_in]                                       = STARTING_heating_system
    [Toutdoor,Tground,Gs]                                                                              = DISTURBANCES    
       
    [C,K_z1,K_z2,p_z1,p_z2] = BuildingParameters()
    [P_norm,P_max,P_min]    = PolynomialCoefficientHP_HC()
    [P_ebt,P_lwc,P_cr]      = PolynomialCoefficientHP_Pl() 
    P_sup                   = PolynomialCoefficientHP_Rad()
    factors                 = DegradationFactor()
    
    # Starting value for maximum capacity of the HP
    Qmax_hp_in = (P_min[0] + P_min[1]*Tout_COND_in + P_min[2]*(Tout_COND_in**2)) + (P_norm[0] + P_norm[1]*(EBT_in) + P_norm[2]*(EBT_in**2))*((P_max[0] + P_max[1]*Tout_COND_in + P_max[2]*(Tout_COND_in**2))-(P_min[0] + P_min[1]*Tout_COND_in + P_min[2]*(Tout_COND_in**2)))
    # Starting value for CR1 and CR2
    CR1_in     = Qh1_in/Qmax_hp_in
    CR2_in     = Qh2_in/Qmax_hp_in     


    # -------------------------------------------------------------------------------
    # OPTIMIZATION PROBLEM
    # -------------------------------------------------------------------------------
    MPC        = GEKKO(remote=False) 
    time       = [t*timestep_hr for t in range(0,len(Toutdoor))]      
    Time       = np.asarray(time)
    MPC.time   = Time    
    shift      = MPC.Param(value = 0.15)
    SHIFT      = 0.15
    # # Parameters
    Cair_ff     = MPC.Param(value = C[0])
    Ce_ff       = MPC.Param(value = C[1]) 
    Ctm         = MPC.Param(value = C[2]) 
    Cair_sf     = MPC.Param(value = C[3])
    Ce_sf       = MPC.Param(value = C[4]) 
    
    Keo_ff      = MPC.Param(value = K_z1[0])
    Kei_ff      = MPC.Param(value = K_z1[1])    
    Ktm_ff      = MPC.Param(value = K_z1[2])
    Kwindinf_ff = MPC.Param(value = K_z1[3])   
    p_ff        = MPC.Param(value = p_z1)
    
    Keo_sf      = MPC.Param(value = K_z2[0])
    Kei_sf      = MPC.Param(value = K_z2[1])  
    Ktm_sf      = MPC.Param(value = K_z2[2])
    Kwindinf_sf = MPC.Param(value = K_z2[3])  
    p_sf        = MPC.Param(value = p_z2) 
    
    EBT         = MPC.Param(value = EBT_in) 
    
    p_nr = [MPC.FV(i) for i in P_norm]    
    p_mx = [MPC.FV(i) for i in P_max]
    p_mn = [MPC.FV(i) for i in P_min]

    p_cr = [MPC.FV(i) for i in P_cr]    
    p_lw = [MPC.FV(i) for i in P_lwc]
    p_et = [MPC.FV(i) for i in P_ebt] 
    p_SP = [MPC.FV(i) for i in P_sup]
    
    df   = [MPC.FV(i) for i in factors] 
    
    # Input variables
    Tout        = MPC.MV(value = Toutdoor)  
    Gsol        = MPC.MV(value = Gs)     
    Tout.STATUS = 0
    Tout.DCOST  = 0   
    Gsol.STATUS = 0
    Gsol.DCOST  = 0

    
    # Decision variables
    CR1                = MPC.MV(value = CR1_in,lb = 0,ub = 1)  
    CR1.STATUS         = 1 
    CR2                = MPC.MV(value = CR2_in,lb = 0,ub = 1)    
    CR2.STATUS         = 1
    COND_SET           = MPC.MV(value = Tout_COND_in,lb = 30 ,ub = 55)  
    COND_SET.STATUS    = 1  
    FR_COND            = MPC.MV(value = FR_COND_in, lb = 0,ub = 0.265)    
    FR_COND.STATUS     = 1    
    
    if Ttm_in > 19.25:
        Ttm    = MPC.SV(value = ((19+Ttm_in)/2))
    else:    
        Ttm    = MPC.SV(value = Ttm_in)
      
    # Controlled variables
    Te_ff         = MPC.SV(value = (Twall_N+Twall_O+Twall_Z+Twall_W)/4) 
    Te_sf         = MPC.SV(value = (Twall_N+Twall_O+Twall_Z+Twall_W)/4)     
    # Controlled variables
    w_air_zone = 100000000000
    Tair_ff    = MPC.CV(value=Tz_1_in, lb = 18, ub = 23)
    Tair_sf    = MPC.CV(value=Tz_2_in, lb = 18, ub = 23)
    
    Tair_ff.STATUS       = 1                     
    Tair_sf.STATUS       = 1  
   
    Tair_ff.SPHI         = Tair_max
    Tair_ff.SPLO         = Tair_min          
    Tair_ff.TAU          = C[0]       
         
    Tair_sf.SPHI         = Tair_max 
    Tair_sf.SPLO         = Tair_min           
    Tair_sf.TAU          = C[1]         

    Tair_ff.WSPHI        = w_air_zone
    Tair_ff.WSPLO        = w_air_zone
    
    Tair_sf.WSPHI        = w_air_zone
    Tair_sf.WSPLO        = w_air_zone
    
    # Equations    
    MPC.Equation(Ce_ff*Te_ff.dt()      == (Tout-Te_ff)*Keo_ff + (Tair_ff-Te_ff)*Kei_ff)
    MPC.Equation(Ce_sf*Te_sf.dt()      == (Tout-Te_sf)*Keo_sf + (Tair_sf-Te_sf)*Kei_sf)
    MPC.Equation(Cair_ff*Tair_ff.dt()  == (Tout-Tair_ff)*Kwindinf_ff + (Te_ff-Tair_ff)*Kei_ff + Ktm_ff*(Ttm-Tair_ff)+p_ff*Gsol + CR1*((p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)) + (p_nr[0] + p_nr[1]*(EBT) + p_nr[2]*(EBT**2))*((p_mx[0] + p_mx[1]*COND_SET + p_mx[2]*(COND_SET**2))-(p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)))))
    MPC.Equation(Cair_sf*Tair_sf.dt()  == (Tout-Tair_sf)*Kwindinf_sf + (Te_sf-Tair_sf)*Kei_sf + Ktm_sf*(Ttm-Tair_sf)+p_sf*Gsol + CR2*((p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)) + (p_nr[0] + p_nr[1]*(EBT) + p_nr[2]*(EBT**2))*((p_mx[0] + p_mx[1]*COND_SET + p_mx[2]*(COND_SET**2))-(p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)))))
    MPC.Equation(Ctm*Ttm.dt()          == Ktm_ff*(Tair_ff-Ttm)+Ktm_sf*(Tair_sf-Ttm))   
    
    MPC.Equation(CR1+CR2 <=1)     
    MPC.Equation(FR_COND*4190*(5) == (CR1+CR2)*((p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)) + (p_nr[0] + p_nr[1]*(EBT) + p_nr[2]*(EBT**2))*((p_mx[0] + p_mx[1]*COND_SET + p_mx[2]*(COND_SET**2))-(p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)))))
    MPC.Equation(FR_COND*4190*(5) <= (p_SP[0]+p_SP[1]*COND_SET)*1.1)
    MPC.Equation(FR_COND*4190*(5) >= (p_SP[0]+p_SP[1]*COND_SET)*0.9) 
    
    
   # Objective function
    Obj = (df[0]+df[1]*(CR1+CR2-shift)+df[2]*(CR1+CR2-shift)**2+df[3]*(CR1+CR2-shift)**3+df[4]*(CR1+CR2-shift)**4+df[5]*(CR1+CR2-shift)**5+df[6]*(CR1+CR2-shift)**6+df[7]*(CR1+CR2-shift)**7+df[8]*(CR1+CR2-shift)**8+df[9]*(CR1+CR2-shift)**9+df[10]*(CR1+CR2-shift)**10)*(p_cr[0]+p_cr[1]*((CR1+CR2)**1)+p_cr[2]*((CR1+CR2)**2)+p_cr[3]*((CR1+CR2)**3) + p_cr[4]*((CR1+CR2)**4)) *((p_lw[0]+p_lw[1]*(COND_SET**1)+p_lw[2]*(COND_SET**2)+p_lw[3]*(COND_SET**3)) + (p_et[0]+p_et[1]*(EBT**1)+p_et[2]*(EBT**2)+p_et[3]*(EBT**3)))  
    MPC.Minimize(Obj)    
       
    # Solver                   
    MPC.options.IMODE    = 6  # MHE
    MPC.options.OTOL     = 1.0e-2
    MPC.options.RTOL     = 1.0e-2
    MPC.options.MAX_ITER = 1000000    
    MPC.solve(disp = False)
    
    print('\nOPTIMIZER STATUS')
    if  MPC.options.SOLVESTATUS == 1:
        print('  Successful solution')
        print('  Solve time = '+ str(MPC.options.SOLVETIME) + ' s')
    else:
        print('  Unsuccessful solution')
    print('---------------------------------------------------------')        
    # -------------------------------------------------------------------------------
    # RESULTS
    # ------ -------------------------------------------------------------------------
    cr1       = CR1.value
    cr2       = CR2.value
    cond_set  = COND_SET.value
    fr_cond   = FR_COND.value    
    
    
    
    Qmax_hp = [(P_min[0] + P_min[1]*cond_set[i] + P_min[2]*(cond_set[i]**2)) + (P_norm[0] + P_norm[1]*(EBT_in) + P_norm[2]*(EBT_in**2))*((P_max[0] + P_max[1]*cond_set[i] + P_max[2]*(cond_set[i]**2))-(P_min[0] + P_min[1]*cond_set[i] + P_min[2]*(cond_set[i]**2))) for i in range(0,len(time))]
    CR      = [cr1[i]+cr2[i] for i in range(0,len(time))]
    
    
    
    if MPC.options.SOLVESTATUS == 1:
        ctrl_opt_status = 1
    else:
        ctrl_opt_status = 0

    obj_tot = MPC.options.OBJFCNVAL
    
    El_hp       = [(P_cr[0]+P_cr[1]*(CR[i]**1)+P_cr[2]*(CR[i]**2)+P_cr[3]*(CR[i]**3) + P_cr[4]*(CR[i]**4)) *((P_lwc[0]+P_lwc[1]*(cond_set[i]**1)+P_lwc[2]*(cond_set[i]**2)+P_lwc[3]*(cond_set[i]**3)) + (P_ebt[0]+P_ebt[1]*(EBT_in**1)+P_ebt[2]*(EBT_in**2)+P_ebt[3]*(EBT_in**3))) for i in range(0,len(time))]
    obj_hp_el   = [(factors[0]+factors[1]*(CR[i]-SHIFT)+factors[2]*(CR[i]-SHIFT)**2+factors[3]*(CR[i]-SHIFT)**3+factors[4]*(CR[i]-SHIFT)**4+factors[5]*(CR[i]-SHIFT)**5+factors[6]*(CR[i]-SHIFT)**6+factors[7]*(CR[i]-SHIFT)**7+factors[8]*(CR[i]-SHIFT)**8+factors[9]*(CR[i]-SHIFT)**9+factors[10]*(CR[i]-SHIFT)**10)*(P_cr[0]+P_cr[1]*(CR[i]**1)+P_cr[2]*(CR[i]**2)+P_cr[3]*(CR[i]**3) + P_cr[4]*(CR[i]**4)) *((P_lwc[0]+P_lwc[1]*(cond_set[i]**1)+P_lwc[2]*(cond_set[i]**2)+P_lwc[3]*(cond_set[i]**3)) + (P_ebt[0]+P_ebt[1]*(EBT_in**1)+P_ebt[2]*(EBT_in**2)+P_ebt[3]*(EBT_in**3))) for i in range(0,len(time))]

    obj_el = sum(obj_hp_el)
    
    ctrl_sh  = []
    ctrl_sh1 = []
    ctrl_sh2 = []
    for i in range(0,len(CR)):
        if CR[i] > 0.05:
          ctrl_sh.append(1) 
        else:
          ctrl_sh.append(0)  
        if CR1[i] > 0.05:
          ctrl_sh1.append(1) 
        else:
          ctrl_sh1.append(0) 
        if CR2[i] > 0.05:
          ctrl_sh2.append(1) 
        else:
          ctrl_sh2.append(0)          
          
          
    Qh1     = [cr1[i]*Qmax_hp[i] for i in range(0,len(time))]
    Qh2     = [cr2[i]*Qmax_hp[i] for i in range(0,len(time))]
    Qhp     = [Qh1[i]+Qh2[i] for i in range(0,len(time))]   
    
    El_hp   = [(P_cr[0]+P_cr[1]*(CR[i]**1)+P_cr[2]*(CR[i]**2)+P_cr[3]*(CR[i]**3) + P_cr[4]*(CR[i]**4)) *((P_lwc[0]+P_lwc[1]*(cond_set[i]**1)+P_lwc[2]*(cond_set[i]**2)+P_lwc[3]*(cond_set[i]**3)) + (P_ebt[0]+P_ebt[1]*(EBT_in**1)+P_ebt[2]*(EBT_in**2)+P_ebt[3]*(EBT_in**3))) for i in range(0,len(time))]
    
    control_action_1 = ctrl_sh
    control_action_2 = cond_set
    control_action_3 = ctrl_sh1
    control_action_4 = ctrl_sh2    
    
    TEMPERATURE     = [Tair_ff.value,Tair_sf.value,Te_ff.value,Te_sf.value,Ttm.value]
    OPERATIVE       = [cr1,cr2,Qh1,Qh2,CR,fr_cond] 
    CONSUMPTION     = [El_hp,obj_hp_el]
    ACTIONS         = [control_action_1,control_action_2,control_action_3,control_action_4]
    OPTIM           = [ctrl_opt_status]
 
    return (TEMPERATURE,OPERATIVE,CONSUMPTION,ACTIONS,OPTIM)
    

