# -*- coding: utf-8 -*-
"""
-------------------------------------------------------------------------------
Update version (25 october 2023)
@author: AMugnini
-------------------------------------------------------------------------------
"""
import numpy as np
from AuxiliaryFunctions import *
from gekko import GEKKO
import matplotlib.pyplot as plt

"""
-------------------------------------------------------------------------------
SETTINGS FOR THE EMPC
(These variables must be set here before the EMPC starts) 
WARNING: do not change the timestep in this script 
-------------------------------------------------------------------------------
"""
# Timestep in the EMPC
timestep_hr       = 10/60 # in hours 
# Prediction Horizon 
PH                = 24 # in hours
# Temperature range granted to the thermostat (in this version is the same for the two thermal zones)
Tzone_min         = 20  # minimum value in °C
Tzone_max         = 21  # maximum value in °C 
"""
-------------------------------------------------------------------------------
INPUT VARIABES FOR THE EMPC
These variables should be included in the loop: variables resulting from 
communication with the system to be controlled. 
PLEASE NOTE these variables shoul be updated at each timestep (t), 
that is, whenever the optimization problem in the EMPC is solved.
-------------------------------------------------------------------------------
"""
# # sarting time, in this version the 0 is set according to the available data 
# #(this means that star_time_hr equal to 0 coincides with the 1 of December)
star_time_hr   = 7*24    # in hours 
Tz_1_in        = 18      # air node thermal zone 1 in °C ('Tair0' in excel file part 1)
Tz_2_in        = 18      # air node thermal zone 2 in °C ('Tair1' in excel file part 1)

Ttm_in         = 17      # thermal mass node thermal zone 1 in °C ('Tinterfloor_1_ext' in excel file part 2)

Twall_N_in     = 17      # inside wall temperatur in °C, wall to north ('Twall1_N_int' in excel file part 2)
Twall_O_in     = 17      # inside wall temperatur in °C, wall to east  ('Twall1_O_int' in excel file part 2)
Twall_Z_in     = 17      # inside wall temperatur in °C, wall to south ('Twall1_Z_int' in excel file part 2)
Twall_W_in     = 17      # inside wall temperatur in °C, wall to west  ('Twall1_W_int' in excel file part 2)

Qh1_in         = 1362.51   # heat power to thermal zone 1 in W ('Quseful0' in excel file part 1)
Qh2_in         = 1474.76   # heat power to thermal zone 2 in W ('Quseful1' in excel file part 1)

Tin_COND_in    = 28.31  # temperature of the water entering the condenser in °C  ('HP_Tcond_in' in excel file part 1)
Tout_COND_in   = 33.12  # water temperature at the outlet of the condenser in °C ('HP_Tcond_out' in excel file part 1)

EBT_in         = 15.19  # temperature of the water entering the evaporator in °C  ('HP_Tevap_in' in excel file part 1)

FR_COND_in     = 0.137898   # water flowrate through the condenser in kg/s ('HP_mflow_cond' in excel file part 1)
     
"""
-------------------------------------------------------------------------------
Disturbances definition (input variables to the LPM moel) in the PH and 
Organization of initial and settings variables.
    DISTURBANCES contains the following variables:
    (defined in the range (star_time_hr,star_time_hr+timestep_hr))
        [outdoor temperarure (in °C), 
          ground temperature (in °C),
          global horizontal irradiation (in W/mq)]     
-------------------------------------------------------------------------------
"""
DISTURBANCES = InputPredicted(timestep_hr,star_time_hr,PH)
# Organization of initial values
STARTING_states         = [Tz_1_in,Tz_2_in,Ttm_in,Twall_N_in,Twall_O_in,Twall_Z_in,Twall_W_in]
STARTING_heating_system = [Qh1_in,Qh2_in,Tin_COND_in,Tout_COND_in, EBT_in, FR_COND_in]
# Organization of settings values
SETTINGS                = [timestep_hr,PH,Tzone_min,Tzone_max]
"""
-------------------------------------------------------------------------------
Solve the optimization problem: This function solves the optimization problem.
The outputs are: 
    (i)   TEMPERATURE: list containing the node temperature in PH 
          [Tz_1,Tz_2,Te_1,Te_2,Ttm_1,Ttm_2]
    (ii)  OPERATIVE: list containing the main HP control operative conditions
          [CR1,CR2,Qh1,Qh2,CR,FR_COND]
    (iii) Pl: variable that contains the electricity from the grid
    (iv)  ACTIONS: list containing the control actions
          [CTRL_HS, COND_SET, CTRL_HS_ZONE_1, CTRL_HS_ZONE_2, CTRL_OPT_STATUS]             
-------------------------------------------------------------------------------
"""
[TEMPERATURE,OPERATIVE,CONS,ACTIONS,OPTIM] = EMPC1(SETTINGS,STARTING_states,STARTING_heating_system,DISTURBANCES)        
[Tz_1,Tz_2,Te_1,Te_2,Ttm]                          = TEMPERATURE
[CR1,CR2, Qh1,Qh2,CR,FR_COND]                      = OPERATIVE
[Pl,obj_hp_el] = CONS
[CTRL_HS, COND_SET, CTRL_HS_ZONE_1,CTRL_HS_ZONE_2] = ACTIONS
[CTRL_OPT_STATUS]     = OPTIM

HC = [Qh1[i]+Qh2[i] for i in range(0,len(Qh1))]    # Total Heating Power HP (Wt)
"""
-------------------------------------------------------------------------------
Definition of control actions to be sent to the system to be controlled         
-------------------------------------------------------------------------------
"""
control_action_1 = CTRL_HS[1]     
control_action_2 = COND_SET[1]    
control_action_3 = CTRL_HS_ZONE_1[1]  
control_action_4 = CTRL_HS_ZONE_2[1]  
control_action_5 = CTRL_OPT_STATUS # if CTRL_OPT_STATUS = 1 Successful solution 
