# -*- coding: utf-8 -*-
"""
---------------------------------------------------------------------------------------------------
Created on 10/06/2025
@author: Alice
---------------------------------------------------------------------------------------------------
"""
import xlsxwriter
import pandas 
import numpy as np
from   gekko import GEKKO

def PolynomialCoefficientHP_HC():
    """
    --------------------------------------------------------------------------------------------
    Plynomial coefficient for the HP model (equation for HC)
    --------------------------------------------------------------------------------------------
    """
    P_norm = [-7.2486987257, 4.5036792304, -0.070427512888]
    P_max  = [9922.9152571, -74.035128715, 0.49597259514]
    P_min  = [9900.7470713, -78.150909991, 0.55532453836]
    return(P_norm,P_max,P_min)

def PolynomialCoefficientHP_Pl():    
    """
    --------------------------------------------------------------------------------------------
    Plynomial coefficient for the HP model (equation for Pl)
    --------------------------------------------------------------------------------------------
    """
    P_ebt = [0.11886085397, 0.6388859793, -0.056597319403, 0.0013000901113]
    P_lwc = [0.11956408425, 0.16098924884, 0.0019264841354, -2.1001154385e-05]
    P_cr  = [-0.11279610066, 278.08858579, -244.74815272, 229.87631828, -64.710510214]
    return(P_ebt,P_lwc,P_cr)

def DegradationFactor():    
    factor = [2.406592465,-23.27915444,168.5090027,-702.77231653,1871.2897708,-3327.1561237,4004.8281137,-3226.3396905,1667.0047907,-499.47941196,65.988437212]
    return factor


def BuildingParameters():  
    """
    --------------------------------------------------------------------------------------------
    Numerical values of the LPM
    --------------------------------------------------------------------------------------------
    """    
    Cair_z1  	= 828.9482476
    Ce_z1	    = 2399.94396
    Ctm_z1	    = 5894.386721
    Keo_z1	    = 3667.959398
    Kei_z1	    = 235.6167284
    Ktmi_z1	    = 459.0150993
    Ktme_z1	    = 35.6933771
    Kwindinf_z1	= 0.005720065
    p_z1	        = 0.120275881
    Cair_z2     = 828.9482476
    Ce_z2	    = 540.6455913
    Ctm_z2   	= 3852.40407
    Keo_z2      = 1030.071312
    Kei_z2      = 65.62699872
    Ktmi_z2     = 216.4643364
    Ktme_z2     = 380.9560447
    Kwindinf_z2	= 0.005030498
    p_z2	    = 0.01487388
    
    C_z1 = [Cair_z1,Ce_z1,Ctm_z1]
    C_z2 = [Cair_z2,Ce_z2,Ctm_z2]    
    K_z1 = [Keo_z1,Kei_z1,Ktmi_z1,Ktme_z1,Kwindinf_z1]
    K_z2 = [Keo_z2,Kei_z2,Ktmi_z2,Ktme_z2,Kwindinf_z2]    
    return(C_z1,C_z2,K_z1,K_z2,p_z1,p_z2)

def TES_SH():  
    U_training      = 6.767454249
    C_training      = 965.03087521
    k_training      = 0
    return(U_training,C_training,k_training)

def InputPredicted(timestep_hr,starting_time_hr,PH):
    """
    --------------------------------------------------------------------------------------------
    Function to select input for LPM in PH
    --------------------------------------------------------------------------------------------
    """    
    # data_part1_name = "ClimateData_TypWeek_no_price.xlsx"  
    data_part1_name = "ClimateData_TypWeek_no_price.xlsx" 
    data_part1      = pandas.read_excel(data_part1_name) 
    t_sta           = int(starting_time_hr/timestep_hr)
    t_end           = int((starting_time_hr+PH)/timestep_hr)    
    Tout_K          = data_part1.iloc[t_sta:t_end, 1].values.tolist()
    GS              = data_part1.iloc[t_sta:t_end, 2].values.tolist()  
    Price           = data_part1.iloc[t_sta:t_end, 3].values.tolist()       
    Toutdoor        = [T-273.15 for T in Tout_K]   
    Tground         = [13 for g in range(0,len(Tout_K))]
    Gs              = [31.4*g for g in GS]
    price           = [p for p in Price]   
    WEATHER         = [Toutdoor,Tground,Gs,price]
    return(WEATHER)


def EMPC4(SETTINGS,STARTING_states,STARTING_heating_system,DISTURBANCES):
    """
    --------------------------------------------------------------------------------------------
    Function for optimization in EMPS
    --------------------------------------------------------------------------------------------
    """
    
    [max_time,timestep_hr,PH,Tair_min,Tair_max,Ttes_top_max,Ttes_top_min,shift_cr,DT_ideal_hp,COND_SET_MAX,T_out_ff_min]               = SETTINGS
    [Tair_ff_in,Tair_sf_in,Ttm_ff_in,Ttm_sf_in,Twall_N,Twall_O,Twall_Z,Twall_W,Ttes_top_in,Ttes_bottom_in,Ttes_30top_in,Ttes_70top_in] = STARTING_states
    [Qh1_in,Qh2_in,Tin_COND_in,Tout_COND_in, EBT_in, FR_COND_in]                                                                       = STARTING_heating_system
    [Toutdoor,Tground,Gs,penalty]                                                                                                      = DISTURBANCES    
       
    [L_training,C_training,k_training] = TES_SH()
    [C_z1,C_z2,K_z1,K_z2,p_z1,p_z2]    = BuildingParameters()
    [P_norm,P_max,P_min]               = PolynomialCoefficientHP_HC()
    [P_ebt,P_lwc,P_cr]                 = PolynomialCoefficientHP_Pl()  
    factors                            = DegradationFactor()
    
    # Starting value for maximum capacity of the HP
    Qmax_hp_in = (P_min[0] + P_min[1]*Tout_COND_in + P_min[2]*(Tout_COND_in**2)) + (P_norm[0] + P_norm[1]*(EBT_in) + P_norm[2]*(EBT_in**2))*((P_max[0] + P_max[1]*Tout_COND_in + P_max[2]*(Tout_COND_in**2))-(P_min[0] + P_min[1]*Tout_COND_in + P_min[2]*(Tout_COND_in**2)))
    # Starting value for Qhp 
    Qhp_in = FR_COND_in*4190*(Tout_COND_in-Ttes_bottom_in)
    # Starting value for CR
    CR_in  = Qhp_in/Qmax_hp_in   
    
    # TES features
    Vtes   = 750                               # (liters)
    hi     = 1650/1000                         # (m)
    Di     = 2*((Vtes/1000)/(3.14*hi))**(1/2)  # (m)
    Across = 3.14*(Di/2)**2                    # tank cross section area (m2)
    Losses = 1000*2.24/24                      # losses for maintenance in operation (from catalog) kW
    Al     = 3.14*(Di)*hi                      # Heat loss area (m2)
    Losses = Losses/Al                         # (W/m2K)
    
    # Weights of the functions associated with the constraints      
    w_setpoint   = 10000
    w_tank       = 10000
    
    # Design flowrates
    FR_hp_design = 0.26548883  # (in kg/s)
    FR_ff_design = 0.13168167  # (in kg/s)
    FR_sf_design = 0.13168167  # (in kg/s)  
    
    time         = [t*timestep_hr for t in range(0,int(PH/timestep_hr))] 
    """
    --------------------------------------------------------------------------------------------
    OPTIMIZATION 
    --------------------------------------------------------------------------------------------
    """
  
    MPC        = GEKKO(remote = False) 
    time       = [t*timestep_hr for t in range(0,len(Toutdoor))]    
    Time       = np.asarray(time)
        
    MPC.time       = Time    
    shift          = MPC.Param(value = shift_cr)
    DT_design_hp   = MPC.Param(value = DT_ideal_hp)

    
    # Parameters
    Cair_ff     = MPC.Param(value = C_z1[0])
    Ce_ff       = MPC.Param(value = C_z1[1]) 
    Ctm_ff      = MPC.Param(value = C_z1[2]) 
    Keo_ff      = MPC.Param(value = K_z1[0])
    Kei_ff      = MPC.Param(value = K_z1[1])    
    Kitm_ff     = MPC.Param(value = K_z1[2])
    Ketm_ff     = MPC.Param(value = K_z1[3])    
    Kwindinf_ff = MPC.Param(value = K_z1[4])   
    p_ff        = MPC.Param(value = p_z1)     
    Cair_sf     = MPC.Param(value = C_z2[0])
    Ce_sf       = MPC.Param(value = C_z2[1])
    Ctm_sf      = MPC.Param(value = C_z2[2])
    Keo_sf      = MPC.Param(value = K_z2[0])
    Kei_sf      = MPC.Param(value = K_z2[1])  
    Kitm_sf     = MPC.Param(value = K_z2[2])
    Ketm_sf     = MPC.Param(value = K_z2[3])
    Kwindinf_sf = MPC.Param(value = K_z2[4])  
    p_sf        = MPC.Param(value = p_z2) 
    
    EBT         = MPC.Param(value = EBT_in) 
    T_in_COND   = MPC.Param(value = Tin_COND_in)
    
    p_nr        = [MPC.FV(i) for i in P_norm]    
    p_mx        = [MPC.FV(i) for i in P_max]
    p_mn        = [MPC.FV(i) for i in P_min]
    
    p_cr    = [MPC.FV(i) for i in P_cr]    
    p_lw    = [MPC.FV(i) for i in P_lwc]
    p_et    = [MPC.FV(i) for i in P_ebt] 
    
    df      = [MPC.FV(i) for i in factors] 
    
    L       = MPC.Param(L_training)
    Ctes    = MPC.Param(C_training)
    K       = MPC.Param(k_training)
    density = MPC.Param(1000) 
    cp      = MPC.Param(4190)
    Tenv    = MPC.Param(10)
    m_ff_design = MPC.Param(FR_ff_design)
    m_sf_design = MPC.Param(FR_sf_design)
    # Decision variables
    CR                 = MPC.MV(value = CR_in,lb = 0,ub = 1)  
    CR.STATUS          = 1 
    Qheat1             = MPC.MV(value = Qh1_in,lb = 0,ub = 6000)    
    Qheat1.STATUS      = 1
    Qheat2             = MPC.MV(value = Qh2_in,lb = 0,ub = 6000)    
    Qheat2.STATUS      = 1
    COND_SET           = MPC.MV(value = Tout_COND_in,lb = 25,ub = COND_SET_MAX)  
    COND_SET.STATUS    = 1  
    FR_COND            = MPC.MV(lb = 0,  ub = FR_hp_design)    
    FR_COND.STATUS     = 1 
    
    # Input variables    
    Tout               = MPC.MV(value = Toutdoor)  
    Tgrn               = MPC.MV(value = Tground)  
    Gsol               = MPC.MV(value = Gs)   
    price              = MPC.MV(value = penalty)     
    
    Tout.STATUS = 0
    Tout.DCOST  = 0   
    Tgrn.STATUS = 0
    Tgrn.DCOST  = 0 
    Gsol.STATUS = 0
    price.DCOST  = 0 
    price.STATUS = 0
    
    # State variables      
    Te_ff          = MPC.SV(value = (Twall_N+Twall_O+Twall_Z+Twall_W)/4) 
    Te_sf          = MPC.SV(value = (Twall_N+Twall_O+Twall_Z+Twall_W)/4) 
    Ttm_ff         = MPC.SV(value = Ttm_ff_in, ub = 29) 
    Ttm_sf         = MPC.SV(value = Ttm_sf_in, ub = 29) 
    Tc             = MPC.SV(Ttes_bottom_in)
    Thm            = MPC.SV(Ttes_30top_in)
    Tcm            = MPC.SV(Ttes_70top_in) 
    T_out_floor_ff = MPC.SV(lb = T_out_ff_min, ub = 60) 
    T_out_floor_sf = MPC.SV(lb = T_out_ff_min, ub = 60) 
    # Controlled variables
    Tair_ff        = MPC.CV(value=Tair_ff_in)
    Tair_sf        = MPC.CV(value=Tair_sf_in)
    Th             = MPC.CV(Ttes_top_in)
    
    Tair_ff.STATUS = 1                     
    Tair_sf.STATUS = 1  
    Th.STATUS      = 1  
    Tair_ff.SPHI   = Tair_max
    Tair_ff.SPLO   = Tair_min         
    Tair_sf.SPHI   = Tair_max 
    Tair_sf.SPLO   = Tair_min   
    Th.SPHI        = Ttes_top_max
    Th.SPLO        = Ttes_top_min     
    Tair_ff.WSPHI  = w_setpoint
    Tair_ff.WSPLO  = w_setpoint
    Tair_sf.WSPHI  = w_setpoint
    Tair_sf.WSPLO  = w_setpoint
    Th.WSPHI       = w_tank
    Th.WSPLO       = w_tank   
    
    # Equations    
    MPC.Equation(Cair_ff*Tair_ff.dt() == (Tout-Tair_ff)*Kwindinf_ff + (Te_ff-Tair_ff)*Kei_ff + Kitm_ff*(Ttm_ff-Tair_ff)+Ketm_sf*(Ttm_sf-Tair_ff)+p_ff*Gsol)
    MPC.Equation(Cair_sf*Tair_sf.dt() == (Tout-Tair_sf)*Kwindinf_sf + (Te_sf-Tair_sf)*Kei_sf+ Kitm_sf*(Ttm_sf-Tair_sf)+p_sf*Gsol)
    MPC.Equation(Ce_ff*Te_ff.dt()     == (Tout-Te_ff)*Keo_ff + (Tair_ff-Te_ff)*Kei_ff)
    MPC.Equation(Ce_sf*Te_sf.dt()     == (Tout-Te_sf)*Keo_sf + (Tair_sf-Te_sf)*Kei_sf)
    MPC.Equation(Ctm_ff*Ttm_ff.dt()   == Kitm_ff*(Tair_ff-Ttm_ff)+Ketm_ff*(Tgrn-Ttm_ff)    + m_ff_design*cp*(Th-T_out_floor_ff))
    MPC.Equation(Ctm_sf*Ttm_sf.dt()   == Kitm_sf*(Tair_sf-Ttm_sf)+Ketm_sf*(Tair_ff-Ttm_sf) + m_sf_design*cp*(Th-T_out_floor_sf)) 
    MPC.Equation((Th-T_out_floor_ff)>=0)
    MPC.Equation((Th-T_out_floor_sf)>=0) 
    
    Qheat1         = MPC.Intermediate(m_ff_design*cp*(Th-T_out_floor_ff))
    Qheat2         = MPC.Intermediate(m_sf_design*cp*(Th-T_out_floor_sf))
    FR_floor_ff    = MPC.Intermediate(m_ff_design*cp*(Th-T_out_floor_ff)/(cp*(Th-T_out_floor_ff)))
    FR_floor_sf    = MPC.Intermediate(m_sf_design*cp*(Th-T_out_floor_sf)/(cp*(Th-T_out_floor_sf)))
    
    
    MPC.Equation(0.25*Ctes*Th.dt()   == FR_COND*cp*(COND_SET-Th)    + (FR_floor_ff+FR_floor_sf)*cp*(Thm-Th)       + K*(Thm-Th) - L*(Th-Tenv))
    MPC.Equation(0.25*Ctes*Thm.dt()  == FR_COND*cp*(Th-Thm)         + (FR_floor_ff+FR_floor_sf)*cp*(Tcm-Thm)      + K*(Tcm-Thm) + K*(Th-Thm)  - L*(Thm-Tenv))
    MPC.Equation(0.25*Ctes*Tcm.dt()  == FR_COND*cp*(Thm-Tcm)        + (FR_floor_ff+FR_floor_sf)*cp*(Tc-Tcm)       + K*(Tc-Tcm)  + K*(Thm-Tcm) - L*(Tcm-Tenv))
    MPC.Equation(0.25*Ctes*Tc.dt()   == FR_COND*cp*(Tcm-Tc)         + (FR_floor_ff)*cp*(T_out_floor_ff-Tc)+(FR_floor_sf)*cp*(T_out_floor_sf-Tc) + K*(Tcm-Tc) -L*(Tc-Tenv))
    MPC.Equation(Th>Tc)
    
    Q_hp = MPC.Intermediate((CR)*((p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)) + (p_nr[0] + p_nr[1]*(EBT) + p_nr[2]*(EBT**2))*((p_mx[0] + p_mx[1]*COND_SET + p_mx[2]*(COND_SET**2))-(p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)))))
    
    MPC.Equation(FR_COND*cp*(COND_SET-Tc) == Q_hp)
    MPC.Equation((COND_SET-Tc) >= DT_design_hp)
    
    E_hp_sh = MPC.Intermediate(df[0]+df[1]*(CR-shift)+df[2]*(CR-shift)**2+df[3]*(CR-shift)**3+df[4]*(CR-shift)**4+df[5]*(CR-shift)**5+df[6]*(CR-shift)**6+df[7]*(CR-shift)**7+df[8]*(CR-shift)**8+df[9]*(CR-shift)**9+df[10]*(CR-shift)**10)*(p_cr[0]+p_cr[1]*(CR**1)+p_cr[2]*(CR**2)+p_cr[3]*(CR**3) + p_cr[4]*(CR**4)) *((p_lw[0]+p_lw[1]*(COND_SET**1)+p_lw[2]*(COND_SET**2)+p_lw[3]*(COND_SET**3)) + (p_et[0]+p_et[1]*(EBT**1)+p_et[2]*(EBT**2)+p_et[3]*(EBT**3)))  
    MPC.Minimize(price*E_hp_sh)
    try:       
        MPC.options.IMODE    = 6
        MPC.options.OTOL     = 1.0e-2
        MPC.options.RTOL     = 1.0e-2
        MPC.options.MAX_TIME = max_time # seconds  
        MPC.options.MAX_ITER = 100000
        MPC.options.SOLVER   = 3 # Select IPOPT
        MPC.solver_options = ['max_cpu_time 150','']  
        MPC.solve(disp = False,debug = False)
        
        print('\nOPTIMIZER STATUS')
        if  MPC.options.SOLVESTATUS == 1:
            print('  Successful solution')
            print('  Solve time = '+ str(MPC.options.SOLVETIME) + ' s')
        else:
            print('  Unsuccessful solution within time')
            print(MPC.options.SOLVESTATUS)
 
        # -------------------------------------------------------------------------------
        # RESULTS
        # ------ -------------------------------------------------------------------------
        cr_hp         = CR.value
        cond_set      = COND_SET.value
        fr_cond       = FR_COND.value      
        fr_floor_ff   = [FR_floor_ff.value[i] for i in range(0,len(FR_floor_ff.value))] 
        fr_floor_sf   = [FR_floor_sf.value[i] for i in range(0,len(FR_floor_sf.value))]  
        To_floor_ff   = T_out_floor_ff.value 
        To_floor_sf   = T_out_floor_sf.value 
        
        To_floor_ff   = FR_COND.value     
        To_floor_sf   = FR_COND.value     
        Qh1           = [Qheat1.value[i] for i in range(0,len(To_floor_ff))]
        Qh2           = [Qheat2.value[i] for i in range(0,len(To_floor_ff))]           
        
        m_ff_design*cp*(Th-T_out_floor_ff)
        
        Qmax_hp = [(P_min[0] + P_min[1]*cond_set[i] + P_min[2]*(cond_set[i]**2)) + (P_norm[0] + P_norm[1]*(EBT_in) + P_norm[2]*(EBT_in**2))*((P_max[0] + P_max[1]*cond_set[i] + P_max[2]*(cond_set[i]**2))-(P_min[0] + P_min[1]*cond_set[i] + P_min[2]*(cond_set[i]**2))) for i in range(0,len(time))]
        CR      = cr_hp  
        Qhp     = [CR[i]*Qmax_hp[i] for i in range(0,len(time))]   
        obj_tot = MPC.options.OBJFCNVAL
        
        SHIFT   = shift_cr
        
        El_hp       = [(P_cr[0]+P_cr[1]*(CR[i]**1)+P_cr[2]*(CR[i]**2)+P_cr[3]*(CR[i]**3) + P_cr[4]*(CR[i]**4)) *((P_lwc[0]+P_lwc[1]*(cond_set[i]**1)+P_lwc[2]*(cond_set[i]**2)+P_lwc[3]*(cond_set[i]**3)) + (P_ebt[0]+P_ebt[1]*(EBT_in**1)+P_ebt[2]*(EBT_in**2)+P_ebt[3]*(EBT_in**3))) for i in range(0,len(time))]
        obj_hp_el   = [(factors[0]+factors[1]*(CR[i]-SHIFT)+factors[2]*(CR[i]-SHIFT)**2+factors[3]*(CR[i]-SHIFT)**3+factors[4]*(CR[i]-SHIFT)**4+factors[5]*(CR[i]-SHIFT)**5+factors[6]*(CR[i]-SHIFT)**6+factors[7]*(CR[i]-SHIFT)**7+factors[8]*(CR[i]-SHIFT)**8+factors[9]*(CR[i]-SHIFT)**9+factors[10]*(CR[i]-SHIFT)**10)*(P_cr[0]+P_cr[1]*(CR[i]**1)+P_cr[2]*(CR[i]**2)+P_cr[3]*(CR[i]**3) + P_cr[4]*(CR[i]**4)) *((P_lwc[0]+P_lwc[1]*(cond_set[i]**1)+P_lwc[2]*(cond_set[i]**2)+P_lwc[3]*(cond_set[i]**3)) + (P_ebt[0]+P_ebt[1]*(EBT_in**1)+P_ebt[2]*(EBT_in**2)+P_ebt[3]*(EBT_in**3))) for i in range(0,len(time))]
    
        obj_el = sum(obj_hp_el)
        
        ctrl_hp  = []
        ctrl_sh1 = []
        ctrl_sh2 = []
        for i in range(0,len(CR)):
            if CR[i] > 0.05:
              ctrl_hp.append(1) 
            else:
              ctrl_hp.append(0)  
            if Qh1[i] > 100:
              ctrl_sh1.append(1) 
            else:
              ctrl_sh1.append(0) 
            if Qh2[i] > 100:
              ctrl_sh2.append(1) 
            else:
              ctrl_sh2.append(0) 
        
        if MPC.options.SOLVESTATUS == 1:
            ctrl_opt_status = 1
        else:
            ctrl_opt_status = 0                 
            
        control_action_1 = ctrl_hp
        control_action_2 = cond_set
        control_action_3 = ctrl_sh1
        control_action_4 = ctrl_sh2    
        control_action_5 = ctrl_opt_status 
        control_action_6 = 1 # if equal to 1 with ctrl_opt_status = 0 problems of unfeasibility; if equal to 0 with ctrl_opt_status = 0 problems of non-convergence in time
        control_action_7 = 0
        
        TEMPERATURE     = [Tair_ff.value,Tair_sf.value,Te_ff.value,Te_sf.value,Ttm_ff.value,Ttm_sf.value,Th.value,Tc.value]
        OPERATIVE       = [CR,Qhp,Qh1,Qh2,fr_cond,fr_floor_ff,fr_floor_sf,To_floor_ff,To_floor_sf] 
        CONSUMPTION     = obj_hp_el
        ACTIONS         = [control_action_1,control_action_2,control_action_3,control_action_4,control_action_5,control_action_6,control_action_7]

    except:
        print("Exceeding the maximum allowable time. \nActuation of RB backup control. ")  
        TEMPERATURE     = [0,0,0,0,0,0,0,[0,0],[0,0]]
        OPERATIVE       = [0,0,0,0,0,0,0,0,0] 
        CONSUMPTION     = 0
        ACTIONS         = [[0,0],[0,0],[0,0],[0,0],0,0,1]
    return (TEMPERATURE,OPERATIVE,CONSUMPTION,ACTIONS)          
          