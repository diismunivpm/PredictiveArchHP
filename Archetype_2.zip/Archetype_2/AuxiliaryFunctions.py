# -*- coding: utf-8 -*-
"""
-------------------------------------------------------------------------------
Update version (25 october 2023)
@author: AMugnini
-------------------------------------------------------------------------------
"""
import xlsxwriter
import pandas 
import numpy as np
from   gekko import GEKKO

def PolynomialCoefficientHP_HC():
    """
    --------------------------------------------------------------------------------------------
    Plynomial coefficient for the HP model (equation for HC)
    --------------------------------------------------------------------------------------------
    """
    P_norm = [-7.2486987257, 4.5036792304, -0.070427512888]
    P_max  = [9922.9152571, -74.035128715, 0.49597259514]
    P_min  = [9900.7470713, -78.150909991, 0.55532453836]
    return(P_norm,P_max,P_min)

def PolynomialCoefficientHP_Pl():    
    """
    --------------------------------------------------------------------------------------------
    Plynomial coefficient for the HP model (equation for Pl)
    --------------------------------------------------------------------------------------------
    """
    P_ebt = [0.11886085397, 0.6388859793, -0.056597319403, 0.0013000901113]
    P_lwc = [0.11956408425, 0.16098924884, 0.0019264841354, -2.1001154385e-05]
    P_cr  = [-0.11279610066, 278.08858579, -244.74815272, 229.87631828, -64.710510214]
    return(P_ebt,P_lwc,P_cr)

def DegradationFactor():    
    factor = [2.406592465,-23.27915444,168.5090027,-702.77231653,1871.2897708,-3327.1561237,4004.8281137,-3226.3396905,1667.0047907,-499.47941196,65.988437212]
    return factor

def PolynomialCoefficientHP_Rad():    

    P_sup = [-14954.845545,553.01603155]

    return P_sup

def BuildingParameters():  
    """
    --------------------------------------------------------------------------------------------
    Numerical values of the LPM
    --------------------------------------------------------------------------------------------
    """   
    
    Cair_z1	    = 569.45550471000000
    Ce_z1	    = 4851.44873680000000
    Ctm	        = 1587591.20000000000000
    Keo_z1	    = 65.14614506500000
    Kei_z1	    = 175.36233673000000
    Ktm_ff	    = 357.60000867000000
    Kwindinf_z1 = 63.67438589300000
    p_z1	    = 0.05548440499200
    Cair_z2	    = 738.13397643000000
    Ce_z2	    = 8345.71062870000000
    Keo_z2	    = 131.01462236000000
    Kei_z2	    = 354.28677110000000
    Ktm_sf	    = 281.82733244000000
    Kwindinf_z2	= 30.22261418900000
    p_z2	    = 0.07874083960700
         
    
    C    = [Cair_z1,Ce_z1,Ctm,Cair_z2,Ce_z2]
    K_z1 = [Keo_z1,Kei_z1,Ktm_ff,Kwindinf_z1]
    K_z2 = [Keo_z2,Kei_z2,Ktm_sf,Kwindinf_z2]
    
    return(C,K_z1,K_z2,p_z1,p_z2)

def TES_SH():    
    Ctes_value = 401.71022672
    UA_value   = 77.979951654
    return(Ctes_value,UA_value)

def InputPredicted(timestep_hr,starting_time_hr,PH):
    """
    --------------------------------------------------------------------------------------------
    Function to select input for LPM in PH
    --------------------------------------------------------------------------------------------
    """    
    data_part1_name = "ClimateData_TypWeek.xlsx"    
    data_part1      = pandas.read_excel(data_part1_name) 
    t_sta           = int(starting_time_hr/timestep_hr)
    t_end           = int((starting_time_hr+PH)/timestep_hr)    
    Tout_K          = data_part1.iloc[t_sta:t_end, 1].values.tolist()
    GS              = data_part1.iloc[t_sta:t_end, 2].values.tolist()       
    Toutdoor        = [T-273.15 for T in Tout_K]   
    Tground         = [13 for g in range(0,len(Tout_K))]
    Gs              = [31.4*g for g in GS]
    WEATHER         = [Toutdoor,Tground,Gs]
    return(WEATHER)

def StateVariables(timestep_hr,starting_time_hr,PH):
    """
    --------------------------------------------------------------------------------------------
    Function to select input for LPM in PH
    --------------------------------------------------------------------------------------------
    """    
    t_sta           = int(starting_time_hr/timestep_hr)
    t_end           = int((starting_time_hr+PH)/timestep_hr)   
   
    data_part1_name   = "ArcheType2_part1.xlsx"
    data_part2_name   = "ArcheType2_part2.xlsx"
    
    data_part1        = pandas.read_excel(data_part1_name)
    data_part2        = pandas.read_excel(data_part2_name)    
    
    Tair0             = data_part1.iloc[t_sta:t_end, 6].values.tolist()
    Tair1             = data_part1.iloc[t_sta:t_end, 7].values.tolist()
    
    Trad0	          = data_part1.iloc[t_sta:t_end, 24].values.tolist()
    Trad1             = data_part1.iloc[t_sta:t_end, 25].values.tolist()    
    Trad_tot          = data_part1.iloc[t_sta:t_end, 26].values.tolist()
    
    
    Twall0_N_int      = data_part2.iloc[t_sta:t_end, 1].values.tolist()
    Twall0_N_ext      = data_part2.iloc[t_sta:t_end, 2].values.tolist()
    Twall0_O_int      = data_part2.iloc[t_sta:t_end, 3].values.tolist()
    Twall0_O_ext      = data_part2.iloc[t_sta:t_end, 4].values.tolist()
    Twall0_Z_int      = data_part2.iloc[t_sta:t_end, 5].values.tolist()
    Twall0_Z_ext      = data_part2.iloc[t_sta:t_end, 6].values.tolist()    
    Twall0_W_int      = data_part2.iloc[t_sta:t_end, 7].values.tolist()
    Twall0_W_ext      = data_part2.iloc[t_sta:t_end, 8].values.tolist()
    
    Twall1_N_int      = data_part2.iloc[t_sta:t_end, 9].values.tolist()
    Twall1_N_ext      = data_part2.iloc[t_sta:t_end, 10].values.tolist()
    Twall1_O_int      = data_part2.iloc[t_sta:t_end, 11].values.tolist()
    Twall1_O_ext      = data_part2.iloc[t_sta:t_end, 12].values.tolist()
    Twall1_Z_int      = data_part2.iloc[t_sta:t_end, 13].values.tolist()
    Twall1_Z_ext      = data_part2.iloc[t_sta:t_end, 14].values.tolist()
    Twall1_W_int      = data_part2.iloc[t_sta:t_end, 15].values.tolist()
    Twall1_W_ext      = data_part2.iloc[t_sta:t_end, 16].values.tolist()
    
    Tfloor0_int       = data_part2.iloc[t_sta:t_end, 17].values.tolist()
    Tfloor0_ext       = data_part2.iloc[t_sta:t_end, 18].values.tolist()
    Tinterfloor_1_int = data_part2.iloc[t_sta:t_end, 19].values.tolist()
    Tinterfloor_1_ext = data_part2.iloc[t_sta:t_end, 20].values.tolist()
    Troof1_int        = data_part2.iloc[t_sta:t_end, 21].values.tolist()
    Troof1_ext        = data_part2.iloc[t_sta:t_end, 22].values.tolist()  
    
        
    SH_TES_Thermostat_Active = data_part2.iloc[t_sta:t_end, 23].values.tolist()
    SH_TES_T_top	         = data_part2.iloc[t_sta:t_end, 24].values.tolist()
    SH_TES_T_middle	         = data_part2.iloc[t_sta:t_end, 25].values.tolist()
    SH_TES_T_bottom          = data_part2.iloc[t_sta:t_end, 26].values.tolist()
    
    Twall0_int = [(Twall0_N_int[i]+Twall0_O_int[i]+Twall0_Z_int[i]+Twall0_W_int[i])/4 for i in range(0,len(Twall1_W_int))]
    Twall1_int = [(Twall1_N_int[i]+Twall1_O_int[i]+Twall1_Z_int[i]+Twall1_W_int[i])/4 for i in range(0,len(Twall1_W_int))]
    Twall0_ext = [(Twall0_N_ext[i]+Twall0_O_ext[i]+Twall0_Z_ext[i]+Twall0_W_ext[i])/4 for i in range(0,len(Twall1_W_int))]
    Twall1_ext = [(Twall1_N_ext[i]+Twall1_O_ext[i]+Twall1_Z_ext[i]+Twall1_W_ext[i])/4 for i in range(0,len(Twall1_W_int))]
       
    Ttm_ff_real = Tinterfloor_1_int
    Ttm_sf_real = Tinterfloor_1_int
    Te_real     = Twall1_int       

    STATE       = [Tair0,Tair1,Ttm_ff_real,Ttm_sf_real,Te_real,SH_TES_T_top,SH_TES_T_bottom]
    return STATE

def HeatingSystem(timestep_hr,starting_time_hr,PH):
    """
    --------------------------------------------------------------------------------------------
    Function to select input for LPM in PH
    --------------------------------------------------------------------------------------------
    """    
    t_sta           = int(starting_time_hr/timestep_hr)
    t_end           = int((starting_time_hr+PH)/timestep_hr)   
   
    data_part1_name   = "ArcheType2_part1.xlsx"
    data_part2_name   = "ArcheType2_part2.xlsx"
    
    data_part1        = pandas.read_excel(data_part1_name)
    data_part2        = pandas.read_excel(data_part2_name)    
    

    Quseful0          = data_part1.iloc[t_sta:t_end, 10].values.tolist()
    Quseful1          = data_part1.iloc[t_sta:t_end, 11].values.tolist()
    ZONE_1            = data_part1.iloc[t_sta:t_end, 12].values.tolist()
    ZONE_2            = data_part1.iloc[t_sta:t_end, 13].values.tolist()
    
    HP_modulation     = data_part1.iloc[t_sta:t_end, 15].values.tolist()
    HP_on             = data_part1.iloc[t_sta:t_end, 16].values.tolist()
    
    HP_Tcond_set      = data_part1.iloc[t_sta:t_end, 17].values.tolist()
    HP_Tcond_out      = data_part1.iloc[t_sta:t_end, 18].values.tolist()
    HP_Tcond_in       = data_part1.iloc[t_sta:t_end, 19].values.tolist()
    HP_Tevap_in       = data_part1.iloc[t_sta:t_end, 20].values.tolist()
    HP_Tevap_out      = data_part1.iloc[t_sta:t_end, 21].values.tolist()
    HP_mflow_cond     = data_part1.iloc[t_sta:t_end, 22].values.tolist()
    Floor0_mflow      = data_part1.iloc[t_sta:t_end, 23].values.tolist()
    Floor1_mflow      = data_part1.iloc[t_sta:t_end, 24].values.tolist()
    BypassValve_mflow = data_part1.iloc[t_sta:t_end, 25].values.tolist()
    
    Trad0	          = data_part1.iloc[t_sta:t_end, 24].values.tolist()
    Trad1             = data_part1.iloc[t_sta:t_end, 25].values.tolist()    
    Trad_tot          = data_part1.iloc[t_sta:t_end, 26].values.tolist()
 
    POWER     = [Quseful0,Quseful1]
    CTRL_ZONE = [ZONE_1, ZONE_2]
    RAD       = [Trad0,Trad1]
    FLORATE   = [HP_mflow_cond,Floor0_mflow,Floor1_mflow,BypassValve_mflow] 
    COND      = [HP_Tcond_set,HP_Tcond_in,HP_Tcond_out]
    EVAP      = [HP_Tevap_in,HP_Tevap_out]
    
    return(POWER,CTRL_ZONE,RAD, FLORATE,COND,EVAP)



def EMPC2(SETTINGS,STARTING_states,STARTING_heating_system,DISTURBANCES):
    """
    --------------------------------------------------------------------------------------------
    Function for optimization in EMPS
    --------------------------------------------------------------------------------------------
    """
    [timestep_hr,PH,Tair_min,Tair_max,Ttes_top_max,Ttes_top_min,shift_cr,DT_ideal]                  = SETTINGS
    [Tz_1_in,Tz_2_in,Ttm_in,Twall_N_in,Twall_O_in,Twall_Z_in,Twall_W_in,Ttes_top_in,Ttes_bottom_in] = STARTING_states
    [Qh1_in,Qh2_in,Tout_COND_in,EBT_in, FR_COND_in]                                                 = STARTING_heating_system
    [Toutdoor,Tground,Gs]                                                                           = DISTURBANCES    
       
    [C,K_z1,K_z2,p_z1,p_z2] = BuildingParameters()
    [Ctes_value,UA_value]   = TES_SH()
    [P_norm,P_max,P_min]    = PolynomialCoefficientHP_HC()
    [P_ebt,P_lwc,P_cr]      = PolynomialCoefficientHP_Pl()  
    factors                 = DegradationFactor()
    P_sup                   = PolynomialCoefficientHP_Rad()
    # Starting value for maximum capacity of the HP
    Qmax_hp_in = (P_min[0] + P_min[1]*Tout_COND_in + P_min[2]*(Tout_COND_in**2)) + (P_norm[0] + P_norm[1]*(EBT_in) + P_norm[2]*(EBT_in**2))*((P_max[0] + P_max[1]*Tout_COND_in + P_max[2]*(Tout_COND_in**2))-(P_min[0] + P_min[1]*Tout_COND_in + P_min[2]*(Tout_COND_in**2)))
    # Starting value for Qhp 
    Qhp_in = FR_COND_in*4190*(Tout_COND_in-Ttes_bottom_in)
    # Starting value for CR
    CR_in  = Qhp_in/Qmax_hp_in
    

    ctrl_tes = [0]+[1 for i in range(0,len(Toutdoor)-1)]
    

    
    
    # -------------------------------------------------------------------------------
    # OPTIMIZATION PROBLEM
    # -------------------------------------------------------------------------------
    MPC        = GEKKO(remote = False) 
    time       = [t*timestep_hr for t in range(0,len(Toutdoor))]    
    Time       = np.asarray(time)
    MPC.time   = Time    
    
    shift      = MPC.Param(value = shift_cr)
    DT_design  = MPC.Param(value = DT_ideal)
    
    # # Parameters
    Cair_ff     = MPC.Param(value = C[0])
    Ce_ff       = MPC.Param(value = C[1]) 
    Ctm         = MPC.Param(value = C[2]) 
    Cair_sf     = MPC.Param(value = C[3])
    Ce_sf       = MPC.Param(value = C[4]) 
    
    Keo_ff      = MPC.Param(value = K_z1[0])
    Kei_ff      = MPC.Param(value = K_z1[1])    
    Ktm_ff      = MPC.Param(value = K_z1[2])
    Kwindinf_ff = MPC.Param(value = K_z1[3])   
    p_ff        = MPC.Param(value = p_z1)
    
    Keo_sf      = MPC.Param(value = K_z2[0])
    Kei_sf      = MPC.Param(value = K_z2[1])  
    Ktm_sf      = MPC.Param(value = K_z2[2])
    Kwindinf_sf = MPC.Param(value = K_z2[3])  
    p_sf        = MPC.Param(value = p_z2)    
   
    EBT         = MPC.Param(value = EBT_in) 

    p_nr = [MPC.FV(i) for i in P_norm]    
    p_mx = [MPC.FV(i) for i in P_max]
    p_mn = [MPC.FV(i) for i in P_min]

    p_cr = [MPC.FV(i) for i in P_cr]    
    p_lw = [MPC.FV(i) for i in P_lwc]
    p_et = [MPC.FV(i) for i in P_ebt] 
    
    df    = [MPC.FV(i) for i in factors] 
    
    p_SP = [MPC.FV(i) for i in P_sup]
    
    Ctes = MPC.Param(value = Ctes_value)
    UA   = MPC.Param(value = UA_value)

    
    # Decision variables
    CR                = MPC.MV(value = CR_in,lb = 0,ub = 1)  
    CR.STATUS         = 1 
    
    Qheat1            = MPC.MV(value = Qh1_in,lb = 0,ub = 6000)    
    Qheat1.STATUS     = 1
    Qheat2            = MPC.MV(value = Qh2_in,lb = 0,ub = 6000)    
    Qheat2.STATUS     = 1
    
    COND_SET          = MPC.MV(value = Tout_COND_in,lb = 30 ,ub = 55)  
    COND_SET.STATUS   = 1  
    FR_COND           = MPC.MV(value = FR_COND_in, lb = 0,ub = 0.265)    
    FR_COND.STATUS    = 1 
    FR_RAD1           = MPC.MV(value = Qh1_in/(4190*10), lb = 0,ub = 0.265)        
    FR_RAD1.STATUS    = 1  
    FR_RAD2           = MPC.MV(value = Qh2_in/(4190*10), lb = 0,ub = 0.265)    
    FR_RAD2.STATUS    = 1
    
    T_RAD1           = MPC.MV(value = Ttes_top_in-10, lb = 20, ub = 40)       
    T_RAD1.STATUS    = 1  
    T_RAD2           = MPC.MV(value = Ttes_top_in-10, lb = 20, ub = 40)     
    T_RAD2.STATUS    = 1
   
    # Input variables    
    Tout        = MPC.MV(value = Toutdoor)  
    Gsol        = MPC.MV(value = Gs)    
    ct          = MPC.MV(value = ctrl_tes)  
    Tout.STATUS = 0
    Tout.DCOST  = 0   
    Gsol.STATUS = 0
    Gsol.DCOST  = 0
    ct.STATUS = 0
    ct.DCOST  = 0
    
    # State variables    
    diff = (Ttes_top_in - Ttes_bottom_in)/9
    
    Ttes_n1           = MPC.SV(Ttes_top_in-diff*0, lb = 20, ub = 60) 
    Ttes_n2           = MPC.SV(Ttes_top_in-diff*1, lb = 20, ub = 60) 
    Ttes_n3           = MPC.SV(Ttes_top_in-diff*2, lb = 20, ub = 60) 
    Ttes_n4           = MPC.SV(Ttes_top_in-diff*3, lb = 20, ub = 60) 
    Ttes_n5           = MPC.SV(Ttes_top_in-diff*4, lb = 20, ub = 60) 
    Ttes_n6           = MPC.SV(Ttes_top_in-diff*5, lb = 20, ub = 60)  
    Ttes_n7           = MPC.SV(Ttes_top_in-diff*6, lb = 20, ub = 60) 
    Ttes_n8           = MPC.SV(Ttes_top_in-diff*7, lb = 20, ub = 60) 
    Ttes_n9           = MPC.SV(Ttes_top_in-diff*8, lb = 20, ub = 60) 
    Ttes_n10          = MPC.SV(Ttes_bottom_in,     lb = 20, ub = 60) 
      
    # Controlled variables
    # States variables    
    if Ttm_in > 19.25:
        Ttm    = MPC.SV(value = ((19+Ttm_in)/2))
    else:    
        Ttm    = MPC.SV(value = Ttm_in)
      
    Te_ff         = MPC.SV(value = (Twall_N_in+Twall_O_in+Twall_Z_in+Twall_W_in)/4) 
    Te_sf         = MPC.SV(value = (Twall_N_in+Twall_O_in+Twall_Z_in+Twall_W_in)/4)    
    # Controlled variables

    w_air_zone = 1000000000000
    Tair_ff    = MPC.CV(value=Tz_1_in, lb = 18, ub = 23)
    Tair_sf    = MPC.CV(value=Tz_2_in, lb = 18, ub = 23)
    
    Tair_ff.STATUS       = 1                     
    Tair_sf.STATUS       = 1  
   
    Tair_ff.SPHI         = Tair_max
    Tair_ff.SPLO         = Tair_min          
    Tair_ff.TAU          = C[0]       
         
    Tair_sf.SPHI         = Tair_max 
    Tair_sf.SPLO         = Tair_min           
    Tair_sf.TAU          = C[1]         

    Tair_ff.WSPHI        = w_air_zone
    Tair_ff.WSPLO        = w_air_zone
    
    Tair_sf.WSPHI        = w_air_zone
    Tair_sf.WSPLO        = w_air_zone
       
    
    # Equations    
    MPC.Equation(Ce_ff*Te_ff.dt()      == (Tout-Te_ff)*Keo_ff + (Tair_ff-Te_ff)*Kei_ff)
    MPC.Equation(Ce_sf*Te_sf.dt()      == (Tout-Te_sf)*Keo_sf + (Tair_sf-Te_sf)*Kei_sf)
    MPC.Equation(Cair_ff*Tair_ff.dt()  == (Tout-Tair_ff)*Kwindinf_ff + (Te_ff-Tair_ff)*Kei_ff + Ktm_ff*(Ttm-Tair_ff)+p_ff*Gsol + Qheat1)
    MPC.Equation(Cair_sf*Tair_sf.dt()  == (Tout-Tair_sf)*Kwindinf_sf + (Te_sf-Tair_sf)*Kei_sf + Ktm_sf*(Ttm-Tair_sf)+p_sf*Gsol + Qheat2)
    MPC.Equation(Ctm*Ttm.dt()          == Ktm_ff*(Tair_ff-Ttm)+Ktm_sf*(Tair_sf-Ttm))    
    
    MPC.Equation(FR_COND*4190*(COND_SET-Ttes_n10) == (CR)*((p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)) + (p_nr[0] + p_nr[1]*(EBT) + p_nr[2]*(EBT**2))*((p_mx[0] + p_mx[1]*COND_SET + p_mx[2]*(COND_SET**2))-(p_mn[0] + p_mn[1]*COND_SET + p_mn[2]*(COND_SET**2)))))
    MPC.Equation(COND_SET-Ttes_n10>=4)

    MPC.Equation((Ctes/10)*Ttes_n1.dt()  == (UA/10)*(10-Ttes_n1)  + FR_COND*4190*(COND_SET-Ttes_n1)    + (FR_RAD1+FR_RAD2)*4190*(Ttes_n2-Ttes_n1))
    MPC.Equation((Ctes/10)*Ttes_n2.dt()  == (UA/10)*(10-Ttes_n2)  + FR_COND*4190*(Ttes_n1-Ttes_n2)     + (FR_RAD1+FR_RAD2)*4190*(Ttes_n3-Ttes_n2))
    MPC.Equation((Ctes/10)*Ttes_n3.dt()  == (UA/10)*(10-Ttes_n3)  + FR_COND*4190*(Ttes_n2-Ttes_n3)     + (FR_RAD1+FR_RAD2)*4190*(Ttes_n4-Ttes_n3))
    MPC.Equation((Ctes/10)*Ttes_n4.dt()  == (UA/10)*(10-Ttes_n4)  + FR_COND*4190*(Ttes_n3-Ttes_n4)     + (FR_RAD1+FR_RAD2)*4190*(Ttes_n5-Ttes_n4))
    MPC.Equation((Ctes/10)*Ttes_n5.dt()  == (UA/10)*(10-Ttes_n5)  + FR_COND*4190*(Ttes_n4-Ttes_n5)     + (FR_RAD1+FR_RAD2)*4190*(Ttes_n6-Ttes_n5))
    MPC.Equation((Ctes/10)*Ttes_n6.dt()  == (UA/10)*(10-Ttes_n6)  + FR_COND*4190*(Ttes_n5-Ttes_n6)     + (FR_RAD1+FR_RAD2)*4190*(Ttes_n7-Ttes_n6))
    MPC.Equation((Ctes/10)*Ttes_n7.dt()  == (UA/10)*(10-Ttes_n7)  + FR_COND*4190*(Ttes_n6-Ttes_n7)     + (FR_RAD1+FR_RAD2)*4190*(Ttes_n8-Ttes_n7))
    MPC.Equation((Ctes/10)*Ttes_n8.dt()  == (UA/10)*(10-Ttes_n8)  + FR_COND*4190*(Ttes_n7-Ttes_n8)     + (FR_RAD1+FR_RAD2)*4190*(Ttes_n9-Ttes_n8))
    MPC.Equation((Ctes/10)*Ttes_n9.dt()  == (UA/10)*(10-Ttes_n9)  + FR_COND*4190*(Ttes_n8-Ttes_n9)     + (FR_RAD1+FR_RAD2)*4190*(Ttes_n10-Ttes_n9))
    MPC.Equation((Ctes/10)*Ttes_n10.dt() == (UA/10)*(10-Ttes_n10) + FR_COND*4190*(Ttes_n9-Ttes_n10)    + FR_RAD1*4190*(T_RAD1-Ttes_n10) + FR_RAD2*4190*(T_RAD2-Ttes_n10))
    
    MPC.Equation(Ttes_n1 >= ct*Ttes_top_min)
    MPC.Equation(ct*Ttes_n1 <= Ttes_top_max)
    
    MPC.Equation(Qheat1== FR_RAD1*4190*(Ttes_n1-T_RAD1))
    MPC.Equation(Qheat2== FR_RAD2*4190*(Ttes_n1-T_RAD2)) 
    MPC.Equation(Qheat1== FR_RAD1*4190*DT_design)
    MPC.Equation(Qheat2== FR_RAD2*4190*DT_design)
    MPC.Equation(Qheat1+Qheat2 <= (p_SP[0]+p_SP[1]*Ttes_n1)*1.25)
    MPC.Equation(Qheat1+Qheat2 >= (p_SP[0]+p_SP[1]*Ttes_n1)*0.75) 

    # Objective function
    Obj = (df[0]+df[1]*(CR-shift)+df[2]*(CR-shift)**2+df[3]*(CR-shift)**3+df[4]*(CR-shift)**4+df[5]*(CR-shift)**5+df[6]*(CR-shift)**6+df[7]*(CR-shift)**7+df[8]*(CR-shift)**8+df[9]*(CR-shift)**9+df[10]*(CR-shift)**10)*(p_cr[0]+p_cr[1]*(CR**1)+p_cr[2]*(CR**2)+p_cr[3]*(CR**3) + p_cr[4]*(CR**4)) *((p_lw[0]+p_lw[1]*(COND_SET**1)+p_lw[2]*(COND_SET**2)+p_lw[3]*(COND_SET**3)) + (p_et[0]+p_et[1]*(EBT**1)+p_et[2]*(EBT**2)+p_et[3]*(EBT**3)))  
    MPC.Minimize(Obj)    
       
    MPC.options.IMODE    = 6  # MHE
    MPC.options.OTOL     = 1.0e-2
    MPC.options.RTOL     = 1.0e-2
    MPC.options.MAX_ITER = 1000000    
    MPC.solve(disp = False)

    
    print('\nOPTIMIZER STATUS')
    if  MPC.options.SOLVESTATUS == 1:
        print('  Successful solution')
        print('  Solve time = '+ str(MPC.options.SOLVETIME) + ' s')
    else:
        print('  Unsuccessful solution')
    print('---------------------------------------------------------')        
    # -------------------------------------------------------------------------------
    # RESULTS
    # ------ -------------------------------------------------------------------------
    cr_hp     = CR.value
    cond_set  = COND_SET.value
    fr_cond   = FR_COND.value      
    fr_rad1   = [FR_RAD1.value[i] for i in range(0,len(FR_RAD1.value))] 
    fr_rad2   = [FR_RAD2.value[i] for i in range(0,len(FR_RAD2.value))]  
    To_rad1   = T_RAD1.value 
    To_rad2   = T_RAD2.value 
    Qh1       = [Qheat1.value[i] for i in range(0,len(To_rad1))]
    Qh2       = [Qheat2.value[i] for i in range(0,len(To_rad1))]
       
    Qmax_hp = [(P_min[0] + P_min[1]*cond_set[i] + P_min[2]*(cond_set[i]**2)) + (P_norm[0] + P_norm[1]*(EBT_in) + P_norm[2]*(EBT_in**2))*((P_max[0] + P_max[1]*cond_set[i] + P_max[2]*(cond_set[i]**2))-(P_min[0] + P_min[1]*cond_set[i] + P_min[2]*(cond_set[i]**2))) for i in range(0,len(time))]
    CR      = cr_hp  
    Qhp     = [CR[i]*Qmax_hp[i] for i in range(0,len(time))]   
    obj_tot = MPC.options.OBJFCNVAL
    
    SHIFT = shift_cr
    
    El_hp       = [(P_cr[0]+P_cr[1]*(CR[i]**1)+P_cr[2]*(CR[i]**2)+P_cr[3]*(CR[i]**3) + P_cr[4]*(CR[i]**4)) *((P_lwc[0]+P_lwc[1]*(cond_set[i]**1)+P_lwc[2]*(cond_set[i]**2)+P_lwc[3]*(cond_set[i]**3)) + (P_ebt[0]+P_ebt[1]*(EBT_in**1)+P_ebt[2]*(EBT_in**2)+P_ebt[3]*(EBT_in**3))) for i in range(0,len(time))]
    obj_hp_el   = [(factors[0]+factors[1]*(CR[i]-SHIFT)+factors[2]*(CR[i]-SHIFT)**2+factors[3]*(CR[i]-SHIFT)**3+factors[4]*(CR[i]-SHIFT)**4+factors[5]*(CR[i]-SHIFT)**5+factors[6]*(CR[i]-SHIFT)**6+factors[7]*(CR[i]-SHIFT)**7+factors[8]*(CR[i]-SHIFT)**8+factors[9]*(CR[i]-SHIFT)**9+factors[10]*(CR[i]-SHIFT)**10)*(P_cr[0]+P_cr[1]*(CR[i]**1)+P_cr[2]*(CR[i]**2)+P_cr[3]*(CR[i]**3) + P_cr[4]*(CR[i]**4)) *((P_lwc[0]+P_lwc[1]*(cond_set[i]**1)+P_lwc[2]*(cond_set[i]**2)+P_lwc[3]*(cond_set[i]**3)) + (P_ebt[0]+P_ebt[1]*(EBT_in**1)+P_ebt[2]*(EBT_in**2)+P_ebt[3]*(EBT_in**3))) for i in range(0,len(time))]

    obj_el = sum(obj_hp_el)
    
    ctrl_hp  = []
    ctrl_sh1 = []
    ctrl_sh2 = []
    for i in range(0,len(CR)):
        if CR[i] > 0.05:
          ctrl_hp.append(1) 
        else:
          ctrl_hp.append(0)  
        if Qh1[i] > 100:
          ctrl_sh1.append(1) 
        else:
          ctrl_sh1.append(0) 
        if Qh2[i] > 100:
          ctrl_sh2.append(1) 
        else:
          ctrl_sh2.append(0)  
          
          
    if MPC.options.SOLVESTATUS == 1:
        ctrl_opt_status = 1
    else:
        ctrl_opt_status = 0    
           
    

    control_action_1 = ctrl_hp
    control_action_2 = cond_set
    control_action_3 = ctrl_sh1
    control_action_4 = ctrl_sh2    
    control_action_5 = ctrl_opt_status 
     
    TEMPERATURE     = [Tair_ff.value,Tair_sf.value,Te_ff.value,Te_sf.value,Ttm.value,Ttes_n1.value,Ttes_n10.value]
    OPERATIVE       = [CR,Qhp,Qh1,Qh2,fr_cond,fr_rad1,fr_rad2,To_rad1,To_rad2] 
    CONSUMPTION     = obj_hp_el
    ACTIONS         = [control_action_1,control_action_2,control_action_3,control_action_4,control_action_5]

 
    return (TEMPERATURE,OPERATIVE,CONSUMPTION,ACTIONS)
    

